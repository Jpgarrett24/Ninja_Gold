from django.urls import path     
from . import views
urlpatterns = [
    path('', views.setup),
    path('setup', views.create),
    path('play', views.index),	
    path('process_money/<str:location>', views.process_money),
    path('reset', views.reset) 
]