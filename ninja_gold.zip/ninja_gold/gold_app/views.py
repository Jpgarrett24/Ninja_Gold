from django.shortcuts import render, redirect, HttpResponse
from time import gmtime, strftime
import random


# Create your views here.
def setup(request):
    return render(request, 'setup.html')

def create(request):
    if 'turns' not in request.session or 'win' not in request.session:
        request.session['turns'] = int(request.POST['turns'])
        request.session['win'] = int(request.POST['win'])
    return redirect('/play')

def index(request):
    if 'gold' not in request.session or 'activities' not in request.session:
        request.session['gold'] = 0
        request.session['activities'] = []
    return render(request, 'index.html')

def process_money(request, location):
    activities = []
    if location == 'farm' and request.session['turns'] >= 7:
        amount = random.randint(10,20)
        request.session['turns'] -= 7
        request.session['gold'] += amount
        request.session['activities'].append('Earned ' + str(amount) + ' golds from the ' + location + ' ' + '(' + strftime('%Y-%m-%d %H:%M %p', gmtime()) + ')')
    if location == 'cave' and request.session['turns'] >= 4:
        amount = random.randint(5,10)
        request.session['turns'] -= 4
        request.session['gold'] += amount
        request.session['activities'].append('Earned ' + str(amount) + ' golds from the ' + location + ' ' + '(' + strftime('%Y-%m-%d %H:%M %p', gmtime()) + ')')
    if location == 'house' and request.session['turns'] >= 2:
        amount = random.randint(2,5)
        request.session['turns'] -= 2
        request.session['gold'] += amount
        request.session['activities'].append('Earned ' + str(amount) + ' golds from the ' + location + ' ' + '(' + strftime('%Y-%m-%d %H:%M %p', gmtime()) + ')')
    if location == 'casino' and request.session['turns'] >= 1:
        amount = random.randint(-50,50)
        request.session['turns'] -= 1
        request.session['gold'] += amount
        if amount > 0:
            request.session['activities'].append('Earned ' + str(amount) + ' golds from the ' + location + ' ' + '(' + strftime('%Y-%m-%d %H:%M %p', gmtime()) + ')')
        else:
            request.session['activities'].append('Entered a casino and lost ' + str(amount) + ' golds... Ouch..' + ' ' + '(' + strftime('%Y-%m-%d %H:%M %p', gmtime()) + ')')
    return redirect('/play')

def reset(request):
    request.session.clear()
    return redirect('/')